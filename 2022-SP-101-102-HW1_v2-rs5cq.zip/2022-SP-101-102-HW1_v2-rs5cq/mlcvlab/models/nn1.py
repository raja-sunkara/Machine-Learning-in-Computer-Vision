from turtle import back
import numpy as np
from sklearn import neural_network
from mlcvlab.nn.losses import l2, l2_grad
from mlcvlab.nn.basis import linear, linear_grad
from mlcvlab.nn.activations import sigmoid, sigmoid_grad
#from .base import Layer

# Implement one layer neural network

#z = w^Tx. Then, y_hat = sigma(z)


class NN1():
    def __init__(self):
#        self.layers = [
#            Layer(None, sigmoid)]
        sizes = [785,1]
        self.sizes = sizes
        self.W = [np.random.randn(y,x)*np.sqrt(1/x*y) for x,y in zip(sizes[:-1], sizes[1:])]  # Xavier initalization (x*y counts the number of weight values)
#        self.W = [np.random.randn(y,x) for x,y in zip(sizes[:-1], sizes[1:])]
#        self.W = None
#        self.W = np.random.randn(1,784)
        # weight initialization

    def nn1(self, x):

        y_hat = sigmoid(linear(x, self.W[0]))

        return y_hat

        return y_hat
#        raise NotImplementedError("NN1 model not implemented")

    def grad(self, x, y, W):
        # TODO
#        Dy_hat = l2_grad(y,self.nn(x))  # computing derivative with respect to y_hat (prediction from neural netowrk)
#        Dz = np.dot(Dy_hat, sigmoid_grad(self.z1))  # computing derivative with respect to z variable (preactivation function)
#        Dw = np.dot(Dz.T,linear_grad(x))  # we are intrested in computing the gradient with resepct to w variable
        
#        return Dw
#        raise NotImplementedError("NN1 gradient (backpropagation) not implemented")


        # 2nd line of tought
        Dw = [np.zeros(w.shape) for w in W]
        m = x.shape[0]

        # feed forward step

        activation = x
        activations = [x] # list to store all the intermediate activations, layer by layer

        zs = []

        for w in W:
            z = linear(activation,w)
            zs.append(z)
            activation = sigmoid(z)
            activations.append(activation)

        # backward pass

#        Dz = l2_grad(y, activations[-1]) * sigmoid_grad(sigmoid(zs[-1]))
        Dz =  (activations[-1] - y) * sigmoid_grad(sigmoid(zs[-1]))
        Dw[-1] = np.dot(Dz, activations[-2].transpose())

        Dw[-1] = Dw[-1]/m    #  dividing with m becuse we need the average grad across all the datapoints

        return Dw


    def emp_loss_grad(self, train_X, train_y, W, layer):
        '''
        To remove the for loop to process for each image instance, I sent the entire 60000 images 
        during the training process and the beacuse of the numpy operations we directly get the 
        gradients for entire dataset in one forward and backward pass
        '''
        # emp_loss_ = 0
        # emp_loss_grad_ = 0

#        emp_loss_grad_ = 0

#        for x,y in zip(train_X, train_y):
#            emp_loss_grad_ + self.grad(x,y,W)

#        emp_loss_grad_ = emp_loss_grad_ / len(train_X)

        emp_loss_grad_ = self.grad(train_X, train_y, W)

#        emp_loss_grad_[-1] = emp_loss_grad_[-1] / m # 
        
        return emp_loss_grad_
#        raise NotImplementedError("NN1 Emperical Loss grad not implemented")




# from sklearn.datasets import fetch_openml
# x, y = fetch_openml("mnist_784", version=1, return_X_y=True, as_frame=False)

# neural_network = NN1()

# x = np.random.randn(784,10000)
# y = np.random.randn(1,10000)

# forward_step = neural_network.nn1(x)
# print(forward_step.shape)

# backward_step = neural_network.grad(x,y,1)
# print(type(backward_step))

# for i in backward_step:
#     print(i)


# empirical_loss_grad = neural_network.emp_loss_grad(x,y,1,1)
# print(empirical_loss_grad)
       


