import numpy as np
from mlcvlab.nn.losses import l2, l2_grad
from mlcvlab.nn.basis import linear, linear_grad
from mlcvlab.nn.activations import relu, sigmoid, sigmoid_grad, relu_grad
#from .base import Layer



class NN2():
    def __init__(self):
#        self.layers = [
#            Layer(None, relu), 
#            Layer(None, sigmoid)]

        sizes = [785,300,1]   # iitializing neural network with 300 hiddent neuron and 1 output and 784 inputs
        self.sizes = sizes

        self.W = [ np.random.randn(y,x)*np.sqrt(1/x*y) if i==0 
        else np.random.randn(y,x)*np.sqrt(2/x*y) for i,(x,y) in enumerate(zip(sizes[:-1], sizes[1:]))  ]
        # for relu layer "He" initialization
        # for sigmoid layer "Xavier" initialization

    def nn2(self, x):
        # TODO
        z1 = linear(x,self.W[0])
        a1 = relu(z1)
        z2 = linear(a1,self.W[1])
        a2 = sigmoid(z2)
        return a2
    #    raise NotImplementedError("NN2 model not implemented")

    def grad(self, x, y, W):
        # TODO

        Dw = [np.zeros(w.shape) for w in self.W]
        m = x.shape[0]

        activation = x
        activations = [x] # list to store all the intermediate activations, layer by layer

        zs = []


        # Forward step
        z = linear(activation, self.W[0])
        zs.append(z)
        activation = relu(z)
        activations.append(activation)

#        z = np.dot(self.W[1],activation)
        z = linear(activation, self.W[1])
        zs.append(z)
        activation = sigmoid(z)
        activations.append(activation)

        # Backward propagation

#        Dz = l2_grad(y, activations[-1])* sigmoid_grad(sigmoid(zs[-1]))
        Dz =  (activations[-1] - y) * sigmoid_grad(sigmoid(zs[-1]))
        Dw[-1] = np.dot(Dz, activations[-2].transpose())

        Dw[-1] = Dw[-1]/m

        z = zs[-2]
        rg = relu_grad(z)
        Dz = np.dot(self.W[-1].transpose(), Dz) * rg
        Dw[-2] = np.dot(Dz, activations[-3].transpose())

        Dw[-2] = Dw[-2]/m

        return Dw

    def emp_loss_grad(self, train_X, train_y, W, layer):
        """
        To remove the for loop to process for each image instance, I sent the entire 60000 images 
        during the training process and the beacuse of the numpy operations we directly get the 
        gradients for entire dataset in one forward and backward pass
        """
        # emp_loss_ = 0
        # emp_loss_grad_ = None
        # emp_loss_grad_ = 0

        # for x,y in zip(train_X, train_y):
        #     emp_loss_grad_ + self.grad(x,y,W)

        # emp_loss_grad_ = emp_loss_grad_ / len(train_X)
        
        # return emp_loss_grad_

        m = len(train_X)

        emp_loss_grad_ = self.grad(train_X, train_y, W)
#        emp_loss_grad_[-1] = emp_loss_grad_[-1]/m
#        emp_loss_grad_[-2] = emp_loss_grad_[-2]/m

        return emp_loss_grad_




# from sklearn.datasets import fetch_openml
# x, y = fetch_openml("mnist_784", version=1, return_X_y=True, as_frame=False)

# neural_network = NN2()

# x = np.random.randn(784,10000)
# y = np.random.randn(1,10000)

# forward_step = neural_network.nn2(x)
# print(forward_step.shape)

# backward_step = neural_network.grad(x,y,1)
# print(type(backward_step))


# empirical_loss_grad = neural_network.emp_loss_grad(x,y,1,1)
# print(empirical_loss_grad)