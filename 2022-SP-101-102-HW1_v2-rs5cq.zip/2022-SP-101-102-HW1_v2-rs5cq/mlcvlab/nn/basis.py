# No additional 3rd party external libraries are allowed
import numpy as np

def linear(x, W):
    # TODO
#    print(x.shape)
    return np.dot(W,x)
#    raise NotImplementedError("Linear function not implemented")
    
def linear_grad(x):
    return x
    raise NotImplementedError("Gradient of Linear function not implemented")

def radial(x, W):
    # TODO
    # x is a 1 x k vector
    # w is a 1 x k vector
    difference_vector = x-W
    return np.dot(difference_vector,difference_vector.T)
#    raise NotImplementedError("Radial Basis function not implemented")
    
def radial_grad(loss_grad_y, x, W):
    # TODO
    # x is a 1 x k vector
    # w is a 1 x k vector
    difference_vector = x - W
    return (2*(W-x)*loss_grad_y).reshape(1,-1)

#    raise NotImplementedError("Gradient of Radial Basis function not implemented")