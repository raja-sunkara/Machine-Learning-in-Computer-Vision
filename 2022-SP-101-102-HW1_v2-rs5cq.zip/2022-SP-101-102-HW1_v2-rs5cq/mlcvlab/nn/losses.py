# No additional 3rd party external libraries are allowed
import numpy as np
from numpy.linalg import norm 

def l2(y, y_hat):
    # TODO
    return np.sqrt(np.dot((y-y_hat),(y-y_hat).T))
    raise NotImplementedError("l2 loss function not implemented")

def l2_grad(y, y_hat):
    # TODO
    z = np.sqrt(np.dot((y-y_hat),(y-y_hat).T))
    return (y-y_hat)/z
    raise NotImplementedError("Gradiant of l2 loss function not implemented")

def cross_entropy(A, Y):
    # What is A and Y
    # TODO
    # this needs to be implemented, not clear what is A and Y
    return  (-Y*np.log(A) - (1-Y) * np.log(1-A)).mean()
    raise NotImplementedError("Cross entropy loss function not implemented")
    
def cross_entropy_grad(y, y_hat):
    # TODO
    return (1-y)/(1-y_hat) - y/y_hat
    raise NotImplementedError("Gradiant of Cross entropy loss function not implemented")


    