# No additional 3rd party external libraries are allowed
from tkinter import W
import numpy as np
from sklearn.model_selection import learning_curve

#import nn1

def Adam(model,  train_X, train_y):
    #TODO

    # initialize states

    print("Training model using Adam")

    learning_rate = 0.01


    # initializing running averages to be all 0 (we take these value as zero for first iteration)
    v_w = [np.zeros(w.shape) for w in model.W]

    s_w = [np.zeros(w.shape) for w in model.W]

#    initial = (v_w, s_w)

#    print("printing type of initial", type(initial))

    beta1, beta2, delta = 0.98, 0.99, 1e-6

    for i in range(100):

        print("training for {} epoch".format(i))

        Dw = model.emp_loss_grad(train_X, train_y, model.W,None)

#        print("inside Adam",Dw)
#        print(Dw[0].shape)

        adam_grad = []

        for w, Dw, v,s in zip(model.W, Dw, v_w,s_w):
            v = beta1 * v + (1-beta1) * Dw
            s = beta2 * s + (1-beta2) * (Dw ** 2)

        #    print("printing v",v)
        #    print("printing s",s)

            v_bias_correction = v/(1 - beta1**(i+1))

            s_bias_correction = s/(1 - beta2**(i+1))

        #    v_bias_correction = v
        #    s_bias_correction =  s

#            print("v_bias_correction",v_bias_correction)
#            print("s_bias_correction",s_bias_correction)

            adam_grad.append(w -  learning_rate * v_bias_correction / (np.sqrt(s_bias_correction) + delta))

        model.W = adam_grad



    return model.W



# model = nn1.NN1()

# x = np.random.randn(784,10000)
# y = np.random.randn(1,10000)
# Dw = model.emp_loss_grad(x,y,None,None)

# print("outside the nabla Dw",Dw)

# # model.W = list(model.W)

# # # model.W[0] = model.W[0]-(1)*Dw[0]
# # # #model.W = [w-(0.1)*nw for w, nw in zip(model.W, Dw)]

# # print(type(model.W))
# # for i in model.W:

# #     print(i)

# final_weights = Adam(model,x,y)


