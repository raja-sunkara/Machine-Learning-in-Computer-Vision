# No additional 3rd party external libraries are allowed
from statistics import mode
import numpy as np
from pyparsing import col

#import nn1


#SGD is implemented by randomly selecting the index of weight matrix and computing the gradient at that updated weight matrix
#Implemnted by having list of matrics.


def SGD(model,  train_X, train_y, lr=0.1, R=100):
    
    epochs = R
#    print(model.W)
#    print("Number of epochs", epochs)
    # computing gradients
#    n = len(train_X)
#    print(n)

    print("Training model using SGD")
    for i in range(epochs):
        print("training for {} epoch".format(i))
        Dw = [np.zeros(w.shape) for w in model.W]

        # update W list so that it contains only one non-zero element and it is position is rnadom

        layer = int(np.random.randint(len(model.W),size=1))   # choosing the random weight matrix(layer)

#        print(int(layer))

        row_index =  int(np.random.randint(model.W[layer].shape[0],size=1))   # choosing random row index
        column_index =  int(np.random.randint(model.W[layer].shape[1], size = 1))  # choosing random columns index

        W_stochastic = [np.zeros(w.shape) for w in model.W]       # assigning the weight matrix to all zeros

        W_stochastic[layer][row_index][column_index] = model.W[layer][row_index][column_index]    # Assigging the random index to non zero value



        Dw = model.emp_loss_grad(train_X, train_y, W_stochastic,None)

#        for i in len(model.W):
#            model.W[i] = model.W[i]-(lr)*Dw[i]

        model.W = [w-(lr)*nw for w, nw in zip(model.W, Dw)]

    #Updated_Weights = None
    

    return model.W
#    raise NotImplementedError("SGD not implemented")




# model = nn1.NN1()
# Dw = model.emp_loss_grad()

# model.W = list(model.W)

# model.W[0] = model.W[0]-(1)*Dw[0]
# #model.W = [w-(0.1)*nw for w, nw in zip(model.W, Dw)]

# print(type(model.W))
# # for i in model.W:
# #     pass
# #     #print(i)

# print(len(model.W))


      