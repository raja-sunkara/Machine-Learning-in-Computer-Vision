class Layer():
    def __init__(self, W, activation):
        self.W  = W
        self.activation = activation