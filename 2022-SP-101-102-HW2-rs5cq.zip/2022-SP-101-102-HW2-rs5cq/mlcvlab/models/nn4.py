import numpy as np
from mlcvlab.nn.losses import l2, l2_grad
from mlcvlab.nn.basis import linear, linear_grad
from mlcvlab.nn.activations import relu, sigmoid, sigmoid_grad, relu_grad
from .base import Layer

from mlcvlab.nn.batchnorm import batchnorm, batchnorm_grad
from mlcvlab.nn.dropout import dropout, dropout_grad


class NN4():
    def __init__(self, use_batchnorm=False, dropout_param=0):
        self.layers = [
            Layer(None, relu),
            Layer(None, relu),
            Layer(None, relu),
            Layer(None, sigmoid)]

        sizes = [785,200,200,200,1]
        self.sizes = sizes

        self.W = [np.random.randn(y,x)*np.sqrt(2/x) if i <=2 
        else np.random.randn(y,x)*np.sqrt(1/x) for i,(x,y) in enumerate(zip(sizes[:-1], sizes[1:]))  ]

        
        self.use_batchnorm = use_batchnorm

        #used in dropout implementation
        self.dropout_param = dropout_param

    def nn4(self, x):
        # TODO
        if self.use_batchnorm:

            z1 = linear(x,self.W[0])
            z1_bar = relu(z1)

            y1 = batchnorm(z1_bar)

            z2 = linear(y1,self.W[1])
            z2_bar = relu(z2)

            y2 = batchnorm(z2_bar)

            z3 = linear(y2,self.W[2])
            z3_bar = relu(z3)

            y3 = batchnorm(z3_bar)

            z4 = linear(y3,self.W[3])
            y = sigmoid(z4)

            return y



        else:
#            print("Inside the function")
            z1 = linear(x,self.W[0])
#            print(z1)
            z1_bar = relu(z1)

            z2 = linear(z1_bar,self.W[1])
            z2_bar = relu(z2)

            z3 = linear(z2_bar,self.W[2])
            z3_bar = relu(z3)

            z4 = linear(z3_bar,self.W[3])
            y = sigmoid(z4)
            
            
            return y
            

        

    def grad(self, x, y):
        # TODO  
        if self.use_batchnorm:

            Dw = [np.zeros(w.shape) for w in self.W]
            m = x.shape[0]

            activation = x
            activations = [x]

            zs=[]

            # Forward step

            z = linear(activation, self.W[0])   # Layer 1
            zs.append(z)
            activation = relu(z)
            activations.append(activation)

            # BN1
            y1 = batchnorm(activation)          # Layer 2
            zs.append(y1)
            activations.append(y1)
            activation = y1


            z = linear(activation, self.W[1])    # Layer 3
            zs.append(z)
            activation = relu(z)
            activations.append(activation)



            # BN2
            y2 = batchnorm(activation)           # Layer 4
            zs.append(y2)
            activations.append(y2)
            activation = y2

            z = linear(activation, self.W[2])    # Layer 5
            zs.append(z)
            activation = relu(z)
            activations.append(activation)

            # BN3
            y3 = batchnorm(activation)           # Layer 6
            zs.append(y3)
            activations.append(y3)
            activation = y3

            z = linear(activation, self.W[3])    # Layer 7
            zs.append(z)
            activation = sigmoid(z)
            activations.append(activation)


            # Backproppagation

            # Layer 7
            Dz =  (activations[-1] - y) * sigmoid_grad(sigmoid(zs[-1]))
            Dw[-1] = np.dot(Dz, activations[-2].transpose())
            Dw[-1] = Dw[-1]/m

            # Layer 6
            z = zs[-2]    # inputs to batch normalization layer druing the forward step
            dx,dgamma, dbeeta= batchnorm_grad(z)
            Dz = dx

            
            # Layer 5
            z = zs[-3]
            rg = relu_grad(z)
            Dz = np.dot(self.W[-1].transpose(), Dz) * rg
            Dw[-2] = np.dot(Dz, activations[-4].transpose())
            Dw[-2] = Dw[-2]/m

            # Layer 4
            z = zs[-4]    # inputs to batch normalization layer druing the forward step
            dx,dgamma, dbeeta= batchnorm_grad(z)
            Dz = dx


            # Layer 3
            z = zs[-5]
            rg = relu_grad(z)
            Dz = np.dot(self.W[-2].transpose(), Dz) * rg
            Dw[-3] = np.dot(Dz, activations[-6].transpose())
            Dw[-3] = Dw[-3]/m

            # Layer 2
            z = zs[-6]    # inputs to batch normalization layer druing the forward step
            dx,dgamma, dbeeta= batchnorm_grad(z)
            Dz = dx


            # Layer 1
            z = zs[-7]
            rg = relu_grad(z)
            Dz = np.dot(self.W[-3].transpose(), Dz) * rg
            Dw[-4] = np.dot(Dz, activations[-8].transpose())
            Dw[-4] = Dw[-4]/m


            return Dw

            

        else:

            Dw = [np.zeros(w.shape) for w in self.W]
            m = x.shape[0]

            activation = x
            activations = [x]

            zs=[]

            # Forward step

            z = linear(activation, self.W[0])
            zs.append(z)
            activation = relu(z)
            activations.append(activation)

            z = linear(activation, self.W[1])
            zs.append(z)
            activation = relu(z)
            activations.append(activation)

            z = linear(activation, self.W[2])
            zs.append(z)
            activation = relu(z)
            activations.append(activation)

            z = linear(activation, self.W[3])
            zs.append(z)
            activation = sigmoid(z)
            activations.append(activation)


            # Backproppagation

            # Layer 4

#            print(activation[-1].shape)
            Dz =  (activations[-1] - y) * sigmoid_grad(sigmoid(zs[-1]))
            Dw[-1] = np.dot(Dz, activations[-2].transpose())
            Dw[-1] = Dw[-1]/m

            
            # Layer 3
            z = zs[-2]
            rg = relu_grad(z)
            Dz = np.dot(self.W[-1].transpose(), Dz) * rg
            Dw[-2] = np.dot(Dz, activations[-3].transpose())
            Dw[-2] = Dw[-2]/m


            # Layer 2
            z = zs[-3]
            rg = relu_grad(z)
            Dz = np.dot(self.W[-2].transpose(), Dz) * rg
            Dw[-3] = np.dot(Dz, activations[-4].transpose())
            Dw[-3] = Dw[-3]/m


            # Layer 1
            z = zs[-4]
            rg = relu_grad(z)
            Dz = np.dot(self.W[-3].transpose(), Dz) * rg
            Dw[-4] = np.dot(Dz, activations[-5].transpose())
            Dw[-4] = Dw[-4]/m

            return Dw

            

    def emp_loss_grad(self, train_X, train_y, layer):
        # emp_loss_ = 0
        # emp_loss_grad_ = None
        
        m = len(train_X)

#        print("Inside the emp_loss_grad")
#        print("X_train shape", train_X.shape)
#        print("Y_train shape",train_y.shape)

        emp_loss_grad_ = self.grad(train_X, train_y)


        return emp_loss_grad_

 