# No additional 3rd party external libraries are allowed
from random import sample
import numpy as np


def batchnorm(x, gamma, beta, eps=1e-5,train=True,momentum=0.9):
    '''
    Input:
    - x: Data of shape (M, D)
    - gamma: Scale parameter of shape (D,)
    - beta: Shift paremeter of shape (D,)
    - mode: 'train' or 'test'; required
    - momentum for the running mean and varience
    output:
    - y
    Suggestion: When you return the output, also return the necessary intermediate values (i.e. mu, variance, x_norm) needed in gradient computation
    '''

    M, D = x.shape
    # M is number of data points and D is number of neurons
    running_mean = np.zeros(D,dtype=x.dtype)
    running_var = np.zeros(D,dtype=x.dtype)

    if train:

        # training phase

        sample_mean = x.mean(axis=0)
        sample_varience = x.var(axis=0)

        running_mean = (1-momentum) * running_mean + momentum* sample_mean

        running_var = (1-momentum) * running_var + momentum* sample_varience

        sample_varience = sample_varience + eps

        std = np.sqrt(sample_varience)
        
        x_hat = (x-sample_mean)/std

        # scale and shift

        y = gamma * x_hat + beta

        return y , (x_hat, (x-sample_mean), std, gamma)

    else:

        # testing phase

        #during testing phase, mean and varience are taken from the running_mean and running_varience

        x_hat = (x - running_mean)/ np.sqrt(running_var+eps)

        y = gamma * x_hat + beta

        return y

 

def batchnorm_grad(x, gamma, beta,dout):

    #dout = upstream graidents which are partial derivative of loss with respect to output of batch norm

    #
    _, cache = batchnorm(x,gamma,beta)

    x_norm = cache[0]   # normalized variable without coaraiate shift
    std = cache[2]
    diffX = cache[1]



    dnorm = dout * gamma      # fist equation in the assignment.  Dl/Dx_hat = Dl/Dy * gamma

    dbeta = np.sum(dout, axis=0, keepdims=True)  # Equation 6, Dl/Db

    dgamma = np.sum(dout* x_norm, axis=0, keepdims=True)  # Eqution 5


    M, D = x.shape


    dvar = - np.sum(dnorm * (diffX/(2*(std**3))), axis=0)  # Eqution 2


    dmu = - np.sum(dnorm / std, axis=0) - (2 / M) * dvar * np.sum(diffX, axis=0)   # Eqution 3

    dx = (dnorm/std) + (dvar * (2/M) * diffX) + (dmu / M)  # EquTION 4


    return dx, dgamma, dbeta




# testing batchnorm

if __name__ == "__main__":
    x = np.random.randn(1,10)
    gamma = np.random.randn(10,)
    beta = np.random.randn(10,)
    dout = np.random.randn(1,10)
    output = batchnorm(x, gamma, beta, eps=1e-5,train=True,momentum=0.9)
    dz,_,_ = batchnorm_grad(x, gamma, beta,dout)
    print(output[0].shape)
    print(x)
    print(output)
    print(dz.shape)


