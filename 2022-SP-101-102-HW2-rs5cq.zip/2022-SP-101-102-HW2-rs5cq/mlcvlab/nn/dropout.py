# No additional 3rd party external libraries are allowed
import numpy as np

def dropout(x, p, mode='test'):
    '''
    Output : should return a tuple containing 
     - z : output of the dropout
     - p : Dropout param
     - mode : 'test' or 'train'
     - mask : 
      - in train mode, it is the dropout mask
      - in test mode, mask will be None.
    
    sample output: (z=, p=0.5, mode='test',mask=None)
    '''
    # TODO Implement logic for both 'test' and 'train' modes.
    if mode == 'train':
        number_of_neurons = x.shape[1]
        binary_trails = np.random.binomial(1,p,size= x.shape)
        
        return x * binary_trails, binary_trails

    elif mode == 'test':
        
        return x * p

def dropout_grad(x,p,z, mode='train'):

    # z here represents the upstream gradients Dl/Dz

    output, binary_mask = dropout(x,p,mode='train')



    # TODO Implement logic for both 'test' and 'train' modes.
    if mode == 'train':
        
        return z * binary_mask
    
    elif mode == 'test':
        
        return z * p




if __name__ == '__main__':
    x = np.random.randn(10,3)
    print(dropout(x,p=0.5,mode='train')[0].shape)
    print(dropout(x,p=0.5,mode='train')[0])
    print(x)

    print(dropout_grad(x,0.5,x).shape)
