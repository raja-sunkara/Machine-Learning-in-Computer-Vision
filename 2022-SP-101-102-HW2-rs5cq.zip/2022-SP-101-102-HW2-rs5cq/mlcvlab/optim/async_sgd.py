# No additional 3rd party external libraries are allowed
import numpy as np

from numba import cuda, jit, njit

def async_sgd(model, train_x_batches, train_y_batches, lr=0.1, R=5):
    '''
    Compute gradient estimate of emp loss on each minibatch in parallel using GPU blocks/threads
    use the most recent gradient estimate computed on a single minibatch to update the weights asynchronously.
    '''
    
    print("Inside async_sgd")
 
    for j in range(R):
        for X_train_batch, y_train_batch in zip(train_x_batches, train_y_batches):

            update_mini_batch(model, X_train_batch, y_train_batch,lr=lr)


#            print("Inside the loop")            
            # update for every batch : sync SGD

        if j%5==0:
            print("Completed training for {} epochs".format(j+5))
            
            
#            Dw += update_mini_batch(model,X_train_batch,y_train_batch)



    return model.W


def update_mini_batch(model,X_train_batch, y_train_batch,lr):
    for (i,j) in zip (X_train_batch, y_train_batch):     # this is async SGD step

        Dw = model.emp_loss_grad(X_train_batch.transpose(), y_train_batch,model.W)

        model.W = [w-(lr)*nw for w, nw in zip(model.W, Dw)]




@cuda.jit(device=True)
#create sync_sgd function inside the jit compiler,that are only called from other functions running on the GPU. 
# (This is similar to CUDA C functions defined with __device__.)
def sync_sgd2(model, X_train_batches, y_train_batches, lr=0.1, R=30):
    for j in prange(R):
        m = len(X_train_batches)
        for batch_index in prange(m):

#        for X_train_batch, y_train_batch in zip(X_train_batches, y_train_batches):

            X_train_batch = X_train_batches[batch_index]
            y_train_batch = y_train_batches[batch_index]


#            print("Inside the loop")

            Dw = model.emp_loss_grad(X_train_batch.transpose(), y_train_batch,model.W)

            model.W = [w-(lr)*nw for w, nw in zip(model.W, Dw)]
            # update for every batch : sync SGD

        if j%5==0:
            print("Completed training for {} epochs".format(j+5))
            
            
#            Dw += update_mini_batch(model,X_train_batch,y_train_batch)



    return model.W



@cuda.jit
def sgd_kernel(mini_batches, DW,model,X_train_batches,y_train_batches):
    start = cuda.grid(1)           # 1D gird since we need to iterate over the index of all batches
    stride = cuda.gridsize(1)

    for i in range(start, mini_batches.shape[0], stride):
        DW[i]= sync_sgd2(model,X_train_batches[i],y_train_batches[i],lr=0.1,R=10)




#mini_batches = list(range(8))     # splitting the entire K batches into K//8
#DW = [np.zeros(w.shape) for w in model.W]
#sgd_kernel(mini_batches,DW,model,X_train_batches,y_train_batches)

#Last step runs the cuda kernel and stores the reasults in DW

